from app import db
from datetime import datetime

class Project(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    product = db.Column(db.String(100))
    start_date = db.Column(db.DateTime, default=datetime.utcnow)
    end_date = db.Column(db.DateTime)
    due_date = db.Column(db.DateTime)
    estimate_dev_time = db.Column(db.Float)  # in hours
    priority = db.Column(db.String(20))
    requestor = db.Column(db.String(100))
    codebase = db.Column(db.String(100))
    status = db.Column(db.String(20), default='Not Started')
    description = db.Column(db.Text)
    notes = db.Column(db.Text)
    tasks = db.relationship('Task', backref='project', lazy='dynamic')
    commits = db.relationship('Commit', backref='project', lazy='dynamic')

    def time_elapsed(self):
        return (datetime.utcnow() - self.start_date).days

class Task(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    due_date = db.Column(db.DateTime)
    status = db.Column(db.String(20), default='Not Started')
    priority = db.Column(db.String(20))
    estimate_time = db.Column(db.Float)  # in hours
    project_id = db.Column(db.Integer, db.ForeignKey('project.id'), nullable=False)
    category = db.Column(db.String(50))  # New field for task category

    def __repr__(self):
        return f'<Task {self.name}>'

class Commit(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    project_id = db.Column(db.Integer, db.ForeignKey('project.id'), nullable=False)
    message = db.Column(db.Text, nullable=False)
    date = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f'<Commit {self.id}>'