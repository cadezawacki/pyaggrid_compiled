from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify, current_app
from app import db
from app.models import Project, Task, Commit
from datetime import datetime, timedelta
from sqlalchemy import func

main = Blueprint('main', __name__)

# Helper function to serialize Task objects
def serialize_task(task):
    return {
        'id': task.id,
        'name': task.name,
        'description': task.description,
        'due_date': task.due_date.isoformat() if task.due_date else None,
        'status': task.status,
        'priority': task.priority,
        'estimate_time': task.estimate_time,
        'project_id': task.project_id,
        'category': task.category
    }

@main.route('/')
def index():
    current_date = datetime.utcnow().date()
    seven_days_later = current_date + timedelta(days=7)
    
    projects = Project.query.all()
    total_projects = len(projects)
    
    # Project status counts
    project_status_counts = db.session.query(Project.status, func.count(Project.id)).\
        group_by(Project.status).\
        all()
    
    project_status_data = [{"name": status, "value": count} for status, count in project_status_counts]
    
    # Additional statistics
    completed_projects = sum(1 for p in projects if p.status == 'Complete')
    in_progress_projects = sum(1 for p in projects if p.status == 'In-Development')
    not_started_projects = sum(1 for p in projects if p.status == 'Not Started')
    high_priority_projects = sum(1 for p in projects if p.priority == 'High')
    
    overdue_projects = sum(1 for p in projects if p.due_date and p.due_date.date() < current_date and p.status != 'Complete')
    upcoming_deadlines = sum(1 for p in projects if p.due_date and current_date <= p.due_date.date() <= seven_days_later and p.status != 'Complete')
    
    # Calculate completion rate
    completion_rate = (completed_projects / total_projects * 100) if total_projects > 0 else 0
    
    # Calculate on-time completion rate
    on_time_completed_projects = sum(1 for p in projects if p.status == 'Complete' and p.end_date and p.due_date and p.end_date <= p.due_date)
    on_time_completion_rate = (on_time_completed_projects / completed_projects * 100) if completed_projects > 0 else 0

    return render_template('index.html', 
                           projects=projects, 
                           total_projects=total_projects,
                           project_status_data=project_status_data,
                           completed_projects=completed_projects,
                           in_progress_projects=in_progress_projects,
                           not_started_projects=not_started_projects,
                           high_priority_projects=high_priority_projects,
                           overdue_projects=overdue_projects,
                           upcoming_deadlines=upcoming_deadlines,
                           completion_rate=completion_rate,
                           on_time_completion_rate=on_time_completion_rate)

@main.route('/project/<int:project_id>')
def project_detail(project_id):
    project = Project.query.get_or_404(project_id)
    estimated_time_remaining = sum(task.estimate_time for task in project.tasks if task.status != 'Complete')
    return render_template('project.html', project=project, estimated_time_remaining=estimated_time_remaining)

@main.route('/project/new', methods=['GET', 'POST'])
def new_project():
    if request.method == 'POST':
        try:
            # Log the received form data for debugging
            current_app.logger.info(f"Received form data: {request.form}")

            # Extract form data with default values
            name = request.form.get('name')
            product = request.form.get('product', '')
            start_date_str = request.form.get('start_date')
            due_date_str = request.form.get('due_date')
            estimate_dev_time = request.form.get('estimate_dev_time', 0)
            priority = request.form.get('priority', 'Medium')
            requestor = request.form.get('requestor', '')
            codebase = request.form.get('codebase', '')
            status = request.form.get('status', 'Not Started')
            description = request.form.get('description', '')

            # Validate required fields
            if not name:
                flash('Project name is required.', 'error')
                return render_template('project_form.html', project=None)

            # Parse dates
            start_date = datetime.strptime(start_date_str, '%Y-%m-%d') if start_date_str else None
            due_date = datetime.strptime(due_date_str, '%Y-%m-%d') if due_date_str else None

            # Create new project
            project = Project(
                name=name,
                product=product,
                start_date=start_date,
                due_date=due_date,
                estimate_dev_time=float(estimate_dev_time) if estimate_dev_time else 0,
                priority=priority,
                requestor=requestor,
                codebase=codebase,
                status=status,
                description=description
            )

            db.session.add(project)
            db.session.commit()

            flash('Project created successfully!', 'success')
            return redirect(url_for('main.index'))
        except Exception as e:
            # Log the error
            current_app.logger.error(f"Error creating project: {str(e)}")
            db.session.rollback()
            flash('An error occurred while creating the project. Please try again.', 'error')

    return render_template('project_form.html', project=None)

@main.route('/project/<int:project_id>/edit', methods=['GET', 'POST'])
def edit_project(project_id):
    project = Project.query.get_or_404(project_id)
    if request.method == 'POST':
        project.name = request.form['name']
        project.product = request.form['product']
        project.start_date = datetime.strptime(request.form['start_date'], '%Y-%m-%d')
        project.due_date = datetime.strptime(request.form['due_date'], '%Y-%m-%d')
        project.estimate_dev_time = float(request.form['estimate_dev_time'])
        project.priority = request.form['priority']
        project.requestor = request.form['requestor']
        project.codebase = request.form['codebase']
        project.status = request.form['status']
        project.description = request.form['description']
        db.session.commit()
        flash('Project updated successfully!', 'success')
        return redirect(url_for('main.project_detail', project_id=project.id))
    return render_template('project_form.html', project=project)

@main.route('/project/<int:project_id>/delete', methods=['POST'])
def delete_project(project_id):
    project = Project.query.get_or_404(project_id)
    db.session.delete(project)
    db.session.commit()
    flash('Project deleted successfully!', 'success')
    return redirect(url_for('main.index'))

@main.route('/api/project/<int:project_id>/tasks', methods=['GET', 'POST'])
def project_tasks(project_id):
    if request.method == 'GET':
        category = request.args.get('category', 'all')
        tasks = Task.query.filter_by(project_id=project_id)
        if category != 'all':
            tasks = tasks.filter_by(category=category)
        return jsonify([serialize_task(task) for task in tasks.all()])
    elif request.method == 'POST':
        data = request.json
        new_task = Task(
            name=data['name'],
            description=data.get('description'),
            due_date=datetime.fromisoformat(data['due_date']) if data.get('due_date') else None,
            status=data.get('status', 'Not Started'),
            priority=data.get('priority'),
            estimate_time=data.get('estimate_time'),
            project_id=project_id,
            category=data.get('category')
        )
        db.session.add(new_task)
        db.session.commit()
        return jsonify(serialize_task(new_task)), 201

@main.route('/api/task/<int:task_id>', methods=['GET'])
def task_operations(task_id):
    task = Task.query.get_or_404(task_id)
    
    if request.method == 'GET':
        return jsonify(serialize_task(task))

@main.route('/api/commit/<int:commit_id>', methods=['DELETE'])
def delete_commit(commit_id):
    commit = Commit.query.get_or_404(commit_id)
    db.session.delete(commit)
    db.session.commit()
    return jsonify({'success': True})
# Add any additional routes or helper functions as needed

@main.route('/api/task/<int:task_id>', methods=['PUT'])
def update_task(task_id):
    task = Task.query.get_or_404(task_id)
    data = request.json
    task.name = data.get('name', task.name)
    task.description = data.get('description', task.description)
    task.due_date = datetime.strptime(data['due_date'], '%Y-%m-%d') if data.get('due_date') else None
    task.status = data.get('status', task.status)
    task.priority = data.get('priority', task.priority)
    task.category = data.get('category', task.category)
    db.session.commit()
    return jsonify(serialize_task(task))

@main.route('/api/project/<int:project_id>/commits', methods=['GET', 'POST'])
def project_commits(project_id):
    if request.method == 'GET':
        commits = Commit.query.filter_by(project_id=project_id).order_by(Commit.date.desc()).all()
        return jsonify([{
            'id': commit.id,
            'message': commit.message,
            'date': commit.date.isoformat()
        } for commit in commits])
    elif request.method == 'POST':
        data = request.json
        new_commit = Commit(
            project_id=project_id,
            message=data['message'],
            date=datetime.utcnow()
        )
        db.session.add(new_commit)
        db.session.commit()
        return jsonify({
            'id': new_commit.id,
            'message': new_commit.message,
            'date': new_commit.date.isoformat()
        }), 201

@main.route('/api/project/<int:project_id>/notes', methods=['GET', 'POST'])
def project_notes(project_id):
    project = Project.query.get_or_404(project_id)
    if request.method == 'GET':
        return jsonify({'notes': project.notes})
    elif request.method == 'POST':
        data = request.json
        project.notes = data['notes']
        db.session.commit()
        return jsonify({'success': True})

@main.route('/project/<int:project_id>/task/new', methods=['GET', 'POST'])
def new_task(project_id):
    project = Project.query.get_or_404(project_id)
    if request.method == 'POST':
        task = Task(
            name=request.form['name'],
            description=request.form.get('description'),
            due_date=datetime.strptime(request.form['due_date'], '%Y-%m-%d') if request.form.get('due_date') else None,
            status=request.form.get('status', 'Not Started'),
            priority=request.form.get('priority'),
            estimate_time=float(request.form['estimate_time']) if request.form.get('estimate_time') else None,
            project_id=project.id,
            category=request.form.get('category')
        )
        db.session.add(task)
        db.session.commit()
        flash('Task created successfully!', 'success')
        return redirect(url_for('main.project_detail', project_id=project.id))
    return render_template('task_form.html', project=project, task=None)


